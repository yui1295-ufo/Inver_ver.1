class LeapYear{
    public static void main(String[] args){
        int year = Integer.parseInt(args[0]);

        if ( year % 400 ==0){  
            System.out.println( year + "は閏年です。");
        }else{
            if( year % 100 == 0){
                System.out.println( year + "は閏年ではありません。");
            }else{
                if( year % 4 == 0){
                    System.out.println( year + "は閏年です。");
                }else{System.out.println( year + "は閏年ではありません。");}
            }
        }
    }
}