import java.util.Random;

class Maximum {
    public static void main(String[] args) {
        Random rand = new Random(Integer.parseInt(args[0]));
        int max = Integer.MIN_VALUE;
        int time = 0;
        while (time < 10) {
            int num = rand.nextInt();
            if (num > max) {
                max = num;
            }
            t += 1;
        }
        System.out.println(max);
    }
}