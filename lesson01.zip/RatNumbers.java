class RatNumbers{
    public static void main(String[] args){
        int number_rads = 2;
        int month = 1;
        while ( month <= 10){
            int pair = number_rads/2;
            number_rads = pair * 12 + number_rads;
            System.out.println( month + "月に" + number_rads + "匹");
            month += 1;
        }
    }
}