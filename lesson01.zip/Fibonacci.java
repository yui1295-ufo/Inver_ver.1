class Fibonacci {
    public static void main(String[] args){
        int n = Integer.parseInt(args[0]);
        int f_1 = 1;
        int f_2 = 0;
        int time = 1;
        int f = 1;

        while (time < n) {
            f = f_1 + f_2;
            time += 1;
            f_2 = f_1;
            f_1 = f;
        }

        System.out.println("f" + n + " = " + f);
    }
}