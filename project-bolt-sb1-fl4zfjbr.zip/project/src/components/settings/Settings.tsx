import React, { useState } from 'react';
import { Info, AlertTriangle } from 'lucide-react';

const Settings: React.FC = () => {
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  
  const handleResetData = () => {
    // Clear all application data
    localStorage.removeItem('appState');
    window.location.reload();
  };
  
  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-gray-600">Manage your preferences and data</p>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
        <div className="border-b border-gray-100">
          <h2 className="text-lg font-medium p-6">Application Settings</h2>
        </div>
        
        <div className="p-6 space-y-6">
          <div>
            <h3 className="text-base font-medium mb-2">About the Application</h3>
            <div className="bg-blue-50 p-4 rounded-md flex">
              <Info size={24} className="text-blue-500 mr-3 flex-shrink-0" />
              <div>
                <p className="text-sm text-gray-700">
                  <span className="font-medium">Objective Reverse Calculation Calendar</span> helps you clarify what needs to be done to achieve your goals and increase your rate of goal attainment.
                </p>
                <p className="text-sm text-gray-700 mt-2">
                  All your data is stored locally in your browser. No data is sent to any server.
                </p>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-base font-medium mb-2">Notification Settings</h3>
            <div className="bg-gray-50 p-4 rounded border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-900">Browser Notifications</p>
                  <p className="text-sm text-gray-600">
                    Receive notifications for upcoming deadlines and tasks
                  </p>
                </div>
                <label className="inline-flex items-center cursor-pointer">
                  <input type="checkbox" value="" className="sr-only peer" />
                  <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-base font-medium mb-2">Reset Application Data</h3>
            <div className="bg-red-50 p-4 rounded-md flex">
              <AlertTriangle size={24} className="text-red-500 mr-3 flex-shrink-0" />
              <div>
                <p className="text-sm text-gray-700">
                  This will permanently delete all your goals, tasks, and application settings. This action cannot be undone.
                </p>
                <button
                  onClick={() => setShowResetConfirm(true)}
                  className="mt-3 px-3 py-1.5 bg-red-600 rounded-md text-sm font-medium text-white hover:bg-red-700"
                >
                  Reset All Data
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="border-b border-gray-100">
          <h2 className="text-lg font-medium p-6">Help & Support</h2>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <h3 className="font-medium mb-2">User Guide</h3>
              <p className="text-sm text-gray-600 mb-3">
                Learn how to use all the features of the application.
              </p>
              <a 
                href="#"
                className="text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                View User Guide
              </a>
            </div>
            
            <div className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <h3 className="font-medium mb-2">Frequently Asked Questions</h3>
              <p className="text-sm text-gray-600 mb-3">
                Find answers to common questions about the application.
              </p>
              <a 
                href="#"
                className="text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                View FAQs
              </a>
            </div>
            
            <div className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <h3 className="font-medium mb-2">Contact Support</h3>
              <p className="text-sm text-gray-600 mb-3">
                Get help with any issues you're experiencing.
              </p>
              <a 
                href="#"
                className="text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                Contact Support
              </a>
            </div>
            
            <div className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <h3 className="font-medium mb-2">Feedback</h3>
              <p className="text-sm text-gray-600 mb-3">
                Share your thoughts and suggestions for improvement.
              </p>
              <a 
                href="#"
                className="text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                Provide Feedback
              </a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-medium text-gray-900 mb-3">Reset All Data</h3>
            <p className="text-gray-600 mb-6">
              Are you sure you want to reset all application data? This will permanently delete all your goals, tasks, and settings.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleResetData}
                className="px-4 py-2 bg-red-600 border border-transparent rounded-md text-sm font-medium text-white hover:bg-red-700"
              >
                Reset Data
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Settings;