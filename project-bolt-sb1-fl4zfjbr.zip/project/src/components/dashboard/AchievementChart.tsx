import React from 'react';
import { Goal, ChartData } from '../../types';

interface AchievementChartProps {
  goals: Goal[];
}

const AchievementChart: React.FC<AchievementChartProps> = ({ goals }) => {
  // Group goals by month created
  const getMonthData = (): ChartData[] => {
    const months: Record<string, { total: number; completed: number }> = {};
    
    // Initialize last 6 months
    const today = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
      const monthKey = `${d.getFullYear()}-${d.getMonth() + 1}`;
      months[monthKey] = { total: 0, completed: 0 };
    }
    
    // Count goals for each month
    goals.forEach(goal => {
      const createdDate = new Date(goal.createdAt);
      const monthKey = `${createdDate.getFullYear()}-${createdDate.getMonth() + 1}`;
      
      // Only count goals from the last 6 months
      if (months[monthKey]) {
        months[monthKey].total += 1;
        if (goal.completed) {
          months[monthKey].completed += 1;
        }
      }
    });
    
    // Convert to array of chart data
    return Object.entries(months).map(([key, data]) => {
      const [year, month] = key.split('-').map(Number);
      const date = new Date(year, month - 1, 1);
      const monthName = date.toLocaleString('default', { month: 'short' });
      
      // Calculate completion rate
      const value = data.total > 0 
        ? Math.round((data.completed / data.total) * 100) 
        : 0;
      
      return {
        label: monthName,
        value
      };
    });
  };
  
  const chartData = getMonthData();
  const maxValue = Math.max(...chartData.map(d => d.value), 100);
  
  return (
    <div className="w-full h-36">
      <div className="flex items-end h-28 justify-between gap-1">
        {chartData.map((data, index) => {
          const height = data.value > 0 
            ? `${(data.value / maxValue) * 100}%` 
            : '5%';
          
          return (
            <div 
              key={index} 
              className="flex flex-col items-center flex-1"
            >
              <div 
                style={{ height }}
                className={`w-full max-w-[30px] rounded-t-sm ${
                  data.value >= 75 
                    ? 'bg-green-500' 
                    : data.value >= 50 
                      ? 'bg-blue-500' 
                      : data.value >= 25 
                        ? 'bg-amber-500' 
                        : 'bg-gray-300'
                }`}
              ></div>
            </div>
          );
        })}
      </div>
      
      <div className="flex justify-between mt-2">
        {chartData.map((data, index) => (
          <div key={index} className="text-xs text-gray-500 text-center w-full">
            {data.label}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AchievementChart;