import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowRight, PlusCircle, ClipboardList, 
  Clock, TrendingUp, Target 
} from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { getTodayTasks, sortGoalsByDeadline, calculateWeeklyAchievementRate } from '../../utils/helpers';
import AchievementChart from './AchievementChart';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { state, dispatch } = useAppContext();
  
  const todayTasks = getTodayTasks(state.goals);
  const upcomingGoals = sortGoalsByDeadline(
    state.goals.filter(goal => !goal.completed && new Date(goal.deadline) > new Date())
  ).slice(0, 3);
  
  const achievementRate = calculateWeeklyAchievementRate(state.goals);
  
  const handleCompleteStep = (goalId: string, stepId: string) => {
    dispatch({ 
      type: 'COMPLETE_STEP',
      payload: {
        goalId,
        stepId
      }
    });
  };
  
  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-gray-600">Track your progress and upcoming tasks</p>
        </div>
        <button
          onClick={() => navigate('/goals/new')}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
        >
          <PlusCircle size={18} className="mr-2" />
          New Goal
        </button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Today's Tasks */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="bg-blue-50 p-4 border-b border-blue-100 flex items-center justify-between">
              <div className="flex items-center">
                <ClipboardList size={20} className="text-blue-600 mr-2" />
                <h2 className="font-medium">Today's Tasks</h2>
              </div>
              <button
                onClick={() => navigate(`/calendar/day/${new Date().toISOString().split('T')[0]}`)}
                className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
              >
                View All
                <ArrowRight size={16} className="ml-1" />
              </button>
            </div>
            
            <div>
              {todayTasks.length === 0 ? (
                <div className="p-6 text-center text-gray-500">
                  <p>No tasks scheduled for today</p>
                  <p className="text-sm mt-1">Great job! Take some time to plan your next steps.</p>
                </div>
              ) : (
                <ul className="divide-y divide-gray-100">
                  {todayTasks.slice(0, 5).map((task) => {
                    const goal = state.goals.find(g => g.id === task.goalId);
                    return (
                      <li key={task.id} className="p-4 hover:bg-gray-50">
                        <div className="flex items-start">
                          <input
                            type="checkbox"
                            checked={task.completed}
                            onChange={() => handleCompleteStep(task.goalId, task.id)}
                            className="mt-1 mr-3 h-4 w-4 text-blue-600 focus:ring-blue-500 rounded"
                          />
                          <div>
                            <p className="font-medium text-gray-900">{task.title}</p>
                            {goal && (
                              <p className="text-xs text-gray-500 mt-1">
                                From: {goal.title}
                              </p>
                            )}
                          </div>
                        </div>
                      </li>
                    );
                  })}
                  
                  {todayTasks.length > 5 && (
                    <li className="p-4 text-center">
                      <button
                        onClick={() => navigate(`/calendar/day/${new Date().toISOString().split('T')[0]}`)}
                        className="text-sm text-blue-600 hover:text-blue-800"
                      >
                        View {todayTasks.length - 5} more tasks
                      </button>
                    </li>
                  )}
                </ul>
              )}
            </div>
          </div>
          
          {/* Upcoming Deadlines */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="bg-amber-50 p-4 border-b border-amber-100 flex items-center justify-between">
              <div className="flex items-center">
                <Clock size={20} className="text-amber-600 mr-2" />
                <h2 className="font-medium">Upcoming Deadlines</h2>
              </div>
              <button
                onClick={() => navigate('/goals')}
                className="text-sm text-amber-600 hover:text-amber-800 flex items-center"
              >
                View All
                <ArrowRight size={16} className="ml-1" />
              </button>
            </div>
            
            <div>
              {upcomingGoals.length === 0 ? (
                <div className="p-6 text-center text-gray-500">
                  <p>No upcoming deadlines</p>
                  <p className="text-sm mt-1">Add a new goal to get started</p>
                </div>
              ) : (
                <ul className="divide-y divide-gray-100">
                  {upcomingGoals.map((goal) => {
                    const daysUntil = Math.ceil(
                      (new Date(goal.deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
                    );
                    
                    return (
                      <li 
                        key={goal.id}
                        className="p-4 hover:bg-gray-50 cursor-pointer"
                        onClick={() => navigate(`/goals/${goal.id}`)}
                      >
                        <div className="flex justify-between">
                          <div>
                            <p className="font-medium text-gray-900">{goal.title}</p>
                            <div className="flex items-center mt-1">
                              <div className="w-24 bg-gray-100 rounded-full h-2 mr-2">
                                <div 
                                  className="bg-blue-600 h-2 rounded-full"
                                  style={{ width: `${goal.progress}%` }}
                                ></div>
                              </div>
                              <span className="text-xs text-gray-600">{goal.progress}% complete</span>
                            </div>
                          </div>
                          <span className={`px-2 py-1 text-xs rounded-full flex items-center ${
                            daysUntil <= 3 
                              ? 'bg-red-100 text-red-800' 
                              : daysUntil <= 7 
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-blue-100 text-blue-800'
                          }`}>
                            {daysUntil === 1 ? 'Tomorrow' : `${daysUntil} days left`}
                          </span>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>
        </div>
        
        <div className="space-y-6">
          {/* Weekly Achievement */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="bg-green-50 p-4 border-b border-green-100 flex items-center">
              <TrendingUp size={20} className="text-green-600 mr-2" />
              <h2 className="font-medium">Weekly Achievement</h2>
            </div>
            
            <div className="p-6 flex flex-col items-center">
              <div className="relative w-32 h-32 mb-4">
                <svg viewBox="0 0 36 36" className="w-full h-full">
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#E5E7EB"
                    strokeWidth="3"
                  />
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#10B981"
                    strokeWidth="3"
                    strokeDasharray={`${achievementRate}, 100`}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-3xl font-bold text-gray-900">{achievementRate}%</span>
                </div>
              </div>
              <p className="text-center text-gray-600">
                of your weekly goals completed
              </p>
            </div>
          </div>
          
          {/* Goal Statistics */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="bg-purple-50 p-4 border-b border-purple-100 flex items-center">
              <Target size={20} className="text-purple-600 mr-2" />
              <h2 className="font-medium">Goal Statistics</h2>
            </div>
            
            <div className="p-4">
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-gray-50 p-3 rounded-lg text-center">
                  <p className="text-2xl font-bold text-gray-900">{state.goals.length}</p>
                  <p className="text-xs text-gray-600">Total Goals</p>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg text-center">
                  <p className="text-2xl font-bold text-gray-900">
                    {state.goals.filter(g => g.completed).length}
                  </p>
                  <p className="text-xs text-gray-600">Completed</p>
                </div>
              </div>
              
              <AchievementChart goals={state.goals} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;