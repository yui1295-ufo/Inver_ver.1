import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Clock, CheckSquare, Target } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { formatDate } from '../../utils/helpers';

const DayView: React.FC = () => {
  const { date } = useParams<{ date: string }>();
  const navigate = useNavigate();
  const { state, dispatch } = useAppContext();
  
  const selectedDate = date ? new Date(date) : new Date();
  const formattedDate = formatDate(selectedDate.toISOString());
  
  // Get all steps scheduled for this date
  const stepsForDay = state.goals.flatMap(goal => 
    goal.steps.filter(step => 
      step.scheduledDate === date
    ).map(step => ({
      ...step,
      goalTitle: goal.title,
      goalId: goal.id
    }))
  );
  
  // Get goals with deadlines on this date
  const deadlinesForDay = state.goals.filter(goal => 
    goal.deadline === date
  );
  
  const handleCompleteStep = (goalId: string, stepId: string) => {
    dispatch({ 
      type: 'COMPLETE_STEP',
      payload: {
        goalId,
        stepId
      }
    });
  };
  
  const navigateToGoal = (goalId: string) => {
    navigate(`/goals/${goalId}`);
  };
  
  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6 flex items-center">
        <button
          onClick={() => navigate('/calendar')}
          className="mr-4 p-2 rounded-full hover:bg-gray-100"
          aria-label="Go back"
        >
          <ArrowLeft size={20} />
        </button>
        <div>
          <h1 className="text-2xl font-bold">{formattedDate}</h1>
          <p className="text-gray-600">
            {stepsForDay.length > 0 
              ? `${stepsForDay.length} task${stepsForDay.length > 1 ? 's' : ''} scheduled` 
              : 'No tasks scheduled'}
          </p>
        </div>
      </div>
      
      <div className="space-y-6">
        {/* Today's tasks */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="bg-blue-50 p-4 border-b border-blue-100 flex items-center">
            <Clock size={20} className="text-blue-600 mr-2" />
            <h2 className="font-medium">Tasks for Today</h2>
          </div>
          
          <div className="divide-y divide-gray-100">
            {stepsForDay.length === 0 ? (
              <div className="p-6 text-center text-gray-500">
                <p>No tasks scheduled for this day</p>
                <p className="text-sm mt-1">Visit your goals to add tasks</p>
              </div>
            ) : (
              stepsForDay.map((step) => (
                <div key={step.id} className="p-4 hover:bg-gray-50">
                  <div className="flex items-start">
                    <button
                      onClick={() => handleCompleteStep(step.goalId, step.id)}
                      className={`mt-1 mr-3 flex-shrink-0 h-5 w-5 rounded border ${
                        step.completed 
                          ? 'bg-green-500 border-green-500 flex items-center justify-center' 
                          : 'border-gray-300 hover:border-blue-500'
                      }`}
                      aria-label={step.completed ? 'Completed' : 'Mark as completed'}
                    >
                      {step.completed && (
                        <CheckSquare size={12} className="text-white" />
                      )}
                    </button>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap justify-between items-start gap-2">
                        <div>
                          <p className={`font-medium ${step.completed ? 'line-through text-gray-500' : 'text-gray-900'}`}>
                            {step.title}
                          </p>
                          <button
                            onClick={() => navigateToGoal(step.goalId)}
                            className="text-xs text-blue-600 hover:text-blue-800 mt-1"
                          >
                            From: {step.goalTitle}
                          </button>
                        </div>
                      </div>
                      {step.description && (
                        <p className={`text-sm mt-1 ${step.completed ? 'text-gray-400' : 'text-gray-600'}`}>
                          {step.description}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
        
        {/* Goals due today */}
        {deadlinesForDay.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="bg-purple-50 p-4 border-b border-purple-100 flex items-center">
              <Target size={20} className="text-purple-600 mr-2" />
              <h2 className="font-medium">Goals Due Today</h2>
            </div>
            
            <div className="divide-y divide-gray-100">
              {deadlinesForDay.map((goal) => (
                <div 
                  key={goal.id} 
                  className="p-4 hover:bg-gray-50 cursor-pointer"
                  onClick={() => navigateToGoal(goal.id)}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium text-gray-900">{goal.title}</p>
                      <div className="flex items-center mt-1">
                        <div className="w-24 bg-gray-100 rounded-full h-2 mr-2">
                          <div 
                            className={`h-2 rounded-full ${goal.completed ? 'bg-green-500' : 'bg-blue-600'}`}
                            style={{ width: `${goal.progress}%` }}
                          ></div>
                        </div>
                        <span className="text-xs text-gray-600">{goal.progress}% complete</span>
                      </div>
                    </div>
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      goal.completed 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {goal.completed ? 'Completed' : 'Due today'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DayView;