import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, ChevronRight } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { formatDate } from '../../utils/helpers';

const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const CalendarView: React.FC = () => {
  const navigate = useNavigate();
  const { state } = useAppContext();
  const [currentDate, setCurrentDate] = useState(new Date());
  
  // Calculate the first day of the month
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
  const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
  
  // Calculate days from previous month to fill the first week
  const daysFromPrevMonth = firstDayOfMonth.getDay();
  
  // Create calendar grid
  const calendarDays = [];
  const totalDays = lastDayOfMonth.getDate();
  
  // Add days from previous month
  const prevMonthLastDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0).getDate();
  for (let i = prevMonthLastDay - daysFromPrevMonth + 1; i <= prevMonthLastDay; i++) {
    calendarDays.push({
      date: new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, i),
      isCurrentMonth: false,
      day: i,
    });
  }
  
  // Add days from current month
  for (let i = 1; i <= totalDays; i++) {
    calendarDays.push({
      date: new Date(currentDate.getFullYear(), currentDate.getMonth(), i),
      isCurrentMonth: true,
      day: i,
    });
  }
  
  // Add days from next month to complete the grid
  const remainingDays = 42 - calendarDays.length; // 6 rows of 7 days
  for (let i = 1; i <= remainingDays; i++) {
    calendarDays.push({
      date: new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, i),
      isCurrentMonth: false,
      day: i,
    });
  }
  
  // Get all steps for the current month view
  const getStepsForDate = (date: Date) => {
    const dateString = date.toISOString().split('T')[0];
    return state.goals.flatMap(goal => 
      goal.steps.filter(step => step.scheduledDate === dateString)
    );
  };
  
  // Check for goals with deadlines on specific dates
  const getDeadlinesForDate = (date: Date) => {
    const dateString = date.toISOString().split('T')[0];
    return state.goals.filter(goal => goal.deadline === dateString);
  };
  
  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prevDate => {
      const newDate = new Date(prevDate);
      if (direction === 'prev') {
        newDate.setMonth(newDate.getMonth() - 1);
      } else {
        newDate.setMonth(newDate.getMonth() + 1);
      }
      return newDate;
    });
  };
  
  const handleSelectDate = (date: Date) => {
    const dateString = date.toISOString().split('T')[0];
    navigate(`/calendar/day/${dateString}`);
  };
  
  const today = new Date();
  const isToday = (date: Date) => {
    return date.getDate() === today.getDate() && 
           date.getMonth() === today.getMonth() && 
           date.getFullYear() === today.getFullYear();
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Calendar</h1>
        <p className="text-gray-600">Visualize your goals and scheduled tasks</p>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="p-4 flex items-center justify-between border-b border-gray-100">
          <h2 className="text-lg font-medium">
            {currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
          </h2>
          <div className="flex space-x-2">
            <button
              onClick={() => navigateMonth('prev')}
              className="p-2 rounded-full hover:bg-gray-100"
              aria-label="Previous month"
            >
              <ArrowLeft size={20} />
            </button>
            <button
              onClick={() => setCurrentDate(new Date())}
              className="px-3 py-1 text-sm border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Today
            </button>
            <button
              onClick={() => navigateMonth('next')}
              className="p-2 rounded-full hover:bg-gray-100"
              aria-label="Next month"
            >
              <ArrowRight size={20} />
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-7 divide-x divide-y divide-gray-100">
          {/* Day headers */}
          {daysOfWeek.map((day) => (
            <div key={day} className="py-2 text-center text-gray-500 text-sm font-medium">
              {day}
            </div>
          ))}
          
          {/* Calendar grid */}
          {calendarDays.map((day, i) => {
            const steps = getStepsForDate(day.date);
            const deadlines = getDeadlinesForDate(day.date);
            const hasActivities = steps.length > 0 || deadlines.length > 0;
            
            return (
              <div 
                key={i}
                onClick={() => handleSelectDate(day.date)}
                className={`min-h-[100px] p-2 relative border border-gray-100 hover:bg-gray-50 cursor-pointer ${
                  !day.isCurrentMonth ? 'bg-gray-50' : ''
                } ${isToday(day.date) ? 'bg-blue-50' : ''}`}
              >
                <div className={`text-right ${
                  !day.isCurrentMonth ? 'text-gray-400' : 
                  isToday(day.date) ? 'text-blue-600 font-bold' : 'text-gray-700'
                }`}>
                  {day.day}
                </div>
                
                <div className="mt-1 overflow-y-auto max-h-20">
                  {steps.slice(0, 2).map((step) => (
                    <div key={step.id} className="text-xs mb-1 truncate">
                      <span className="inline-block w-2 h-2 rounded-full bg-blue-400 mr-1"></span>
                      {step.title}
                    </div>
                  ))}
                  
                  {deadlines.slice(0, 2).map((goal) => (
                    <div key={goal.id} className="text-xs mb-1 truncate">
                      <span className="inline-block w-2 h-2 rounded-full bg-purple-400 mr-1"></span>
                      {goal.title} due
                    </div>
                  ))}
                  
                  {hasActivities && steps.length + deadlines.length > 2 && (
                    <div className="text-xs text-gray-500 flex items-center">
                      <span className="mr-1">more</span>
                      <ChevronRight size={12} />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      
      <div className="mt-6 bg-white rounded-lg shadow-sm p-4">
        <h3 className="text-sm font-medium mb-3">Legend</h3>
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center">
            <span className="inline-block w-3 h-3 rounded-full bg-blue-400 mr-2"></span>
            <span className="text-sm">Scheduled tasks</span>
          </div>
          <div className="flex items-center">
            <span className="inline-block w-3 h-3 rounded-full bg-purple-400 mr-2"></span>
            <span className="text-sm">Goal deadlines</span>
          </div>
          <div className="flex items-center">
            <span className="inline-block w-4 h-4 rounded-sm bg-blue-50 mr-2"></span>
            <span className="text-sm">Today</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalendarView;