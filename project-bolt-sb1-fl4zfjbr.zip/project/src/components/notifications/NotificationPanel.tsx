import React from 'react';
import { useAppContext } from '../../context/AppContext';
import { formatDate } from '../../utils/helpers';
import { Check, Clock, Award, AlertTriangle } from 'lucide-react';

interface NotificationPanelProps {
  onClose: () => void;
}

const NotificationPanel: React.FC<NotificationPanelProps> = ({ onClose }) => {
  const { state, dispatch } = useAppContext();
  
  const markAsRead = (id: string) => {
    dispatch({ type: 'READ_NOTIFICATION', payload: id });
  };
  
  const getIcon = (type: string) => {
    switch (type) {
      case 'deadline':
        return <Clock size={18} className="text-amber-500" />;
      case 'achievement':
        return <Award size={18} className="text-green-500" />;
      default:
        return <AlertTriangle size={18} className="text-blue-500" />;
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden max-h-[80vh] flex flex-col">
      <div className="p-4 border-b border-gray-100 flex justify-between items-center">
        <h3 className="font-medium">Notifications</h3>
        <button 
          onClick={onClose}
          className="text-gray-500 hover:text-gray-700"
        >
          <span className="sr-only">Close</span>
          <Check size={20} />
        </button>
      </div>
      
      <div className="overflow-y-auto flex-grow">
        {state.notifications.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            No notifications
          </div>
        ) : (
          <ul className="divide-y divide-gray-100">
            {state.notifications.map((notification) => (
              <li 
                key={notification.id}
                className={`p-4 hover:bg-gray-50 transition-colors cursor-pointer ${
                  notification.read ? 'opacity-70' : 'bg-blue-50'
                }`}
                onClick={() => markAsRead(notification.id)}
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1 mr-3">
                    {getIcon(notification.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900">{notification.title}</p>
                    <p className="text-sm text-gray-600">{notification.message}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {formatDate(notification.createdAt)}
                    </p>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default NotificationPanel;