import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { MessageSquare, Send, ArrowLeft, Loader2 } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { generateId, createNotification, getTodayDate } from '../../utils/helpers';
import { Goal, Step } from '../../types';

// Simulated Q&A flow for goal planning
const questionFlow = [
  "What's the main reason you want to achieve this goal?",
  "How would you break this goal down into smaller steps?",
  "When do you typically have time to work on this goal?",
  "What obstacles might prevent you from achieving this goal?",
  "What resources or support do you need to succeed?"
];

const AIAssistant: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { dispatch } = useAppContext();
  const { goalData } = location.state || { goalData: { title: '', description: '', deadline: '' } };
  
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [currentAnswer, setCurrentAnswer] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  
  const handleAnswerChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setCurrentAnswer(e.target.value);
  };
  
  const handleSubmitAnswer = () => {
    if (!currentAnswer.trim()) return;
    
    const newAnswers = [...answers, currentAnswer];
    setAnswers(newAnswers);
    setCurrentAnswer('');
    
    if (currentQuestion < questionFlow.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      generatePlan(newAnswers);
    }
  };
  
  const generatePlan = (allAnswers: string[]) => {
    setIsGenerating(true);
    
    // Simulate AI processing time
    setTimeout(() => {
      // Create goal with simulated AI-generated steps
      const deadline = new Date(goalData.deadline);
      const today = new Date();
      const daysBetween = Math.max(1, Math.floor((deadline.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
      
      // Generate steps based on user's second answer (breaking down the goal)
      const stepsText = allAnswers[1];
      let generatedSteps: Step[] = [];
      
      // Simple parsing of steps from the user's answer
      const stepLines = stepsText.split(/[.,\n]/g).filter(line => line.trim().length > 5);
      
      generatedSteps = stepLines.map((step, index) => {
        // Calculate evenly spaced deadlines
        const stepDeadline = new Date(today);
        stepDeadline.setDate(today.getDate() + Math.floor(daysBetween * ((index + 1) / (stepLines.length + 1))));
        
        return {
          id: generateId(),
          goalId: '', // will be set below
          title: step.trim(),
          description: '',
          deadline: stepDeadline.toISOString().split('T')[0],
          completed: false,
          scheduledDate: stepDeadline.toISOString().split('T')[0]
        };
      });
      
      // If no valid steps were parsed, create some generic ones
      if (generatedSteps.length === 0) {
        const numSteps = Math.min(5, daysBetween);
        generatedSteps = Array.from({ length: numSteps }).map((_, index) => {
          const stepDeadline = new Date(today);
          stepDeadline.setDate(today.getDate() + Math.floor(daysBetween * ((index + 1) / (numSteps + 1))));
          
          return {
            id: generateId(),
            goalId: '', // will be set below
            title: `Step ${index + 1} for ${goalData.title}`,
            description: `Generated step for achieving ${goalData.title}`,
            deadline: stepDeadline.toISOString().split('T')[0],
            completed: false,
            scheduledDate: stepDeadline.toISOString().split('T')[0]
          };
        });
      }
      
      const goalId = generateId();
      
      // Set the goalId for all steps
      generatedSteps = generatedSteps.map(step => ({
        ...step,
        goalId
      }));
      
      const newGoal: Goal = {
        id: goalId,
        title: goalData.title,
        description: goalData.description || `Goal created with AI assistance based on your answers.`,
        deadline: goalData.deadline,
        createdAt: new Date().toISOString(),
        steps: generatedSteps,
        aiGenerated: true,
        completed: false,
        progress: 0
      };
      
      dispatch({ type: 'ADD_GOAL', payload: newGoal });
      
      // Create notification
      dispatch({
        type: 'ADD_NOTIFICATION',
        payload: createNotification(
          'AI Plan Generated',
          `Your AI-assisted plan for "${newGoal.title}" is ready with ${generatedSteps.length} steps.`,
          'achievement'
        )
      });
      
      navigate(`/goals/${goalId}`);
    }, 2000); // Simulated delay
  };
  
  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmitAnswer();
    }
  };
  
  const goBack = () => {
    navigate(-1);
  };
  
  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6 flex items-center">
        <button
          onClick={goBack}
          className="mr-4 p-2 rounded-full hover:bg-gray-100"
          aria-label="Go back"
        >
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-2xl font-bold">AI Goal Planning Assistant</h1>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="p-6 bg-blue-50 border-b border-blue-100">
          <div className="flex items-start">
            <div className="bg-blue-600 rounded-full p-2 mr-3">
              <MessageSquare size={20} className="text-white" />
            </div>
            <div>
              <h2 className="font-medium text-gray-900">
                Planning "{goalData.title}"
              </h2>
              <p className="text-sm text-gray-600 mt-1">
                I'll help you break down your goal into manageable steps and create a realistic schedule.
              </p>
            </div>
          </div>
        </div>
        
        <div className="p-6 max-h-96 overflow-y-auto">
          <div className="space-y-6">
            {answers.map((answer, index) => (
              <div key={index} className="space-y-4">
                <div className="flex">
                  <div className="bg-blue-100 rounded-lg p-4 max-w-[80%]">
                    <p className="text-sm text-gray-800">{questionFlow[index]}</p>
                  </div>
                </div>
                <div className="flex justify-end">
                  <div className="bg-gray-100 rounded-lg p-4 max-w-[80%]">
                    <p className="text-sm text-gray-800">{answer}</p>
                  </div>
                </div>
              </div>
            ))}
            
            {answers.length <= questionFlow.length - 1 && (
              <div className="flex">
                <div className="bg-blue-100 rounded-lg p-4 max-w-[80%]">
                  <p className="text-sm text-gray-800">{questionFlow[currentQuestion]}</p>
                </div>
              </div>
            )}
            
            {isGenerating && (
              <div className="flex items-center justify-center py-4">
                <Loader2 size={24} className="animate-spin text-blue-600" />
                <span className="ml-2 text-gray-600">Generating your personalized plan...</span>
              </div>
            )}
          </div>
        </div>
        
        {!isGenerating && answers.length <= questionFlow.length - 1 && (
          <div className="p-4 border-t border-gray-100">
            <div className="flex items-center">
              <textarea
                value={currentAnswer}
                onChange={handleAnswerChange}
                onKeyPress={handleKeyPress}
                placeholder="Type your answer..."
                rows={2}
                className="flex-1 resize-none border-0 bg-transparent p-2 focus:ring-0 focus:outline-none"
              />
              <button
                onClick={handleSubmitAnswer}
                disabled={!currentAnswer.trim()}
                className={`ml-2 rounded-full p-2 ${
                  currentAnswer.trim() 
                    ? 'bg-blue-600 text-white hover:bg-blue-700' 
                    : 'bg-gray-200 text-gray-400'
                }`}
              >
                <Send size={20} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIAssistant;