import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, CheckCircle, Calendar, Plus, 
  Trash2, Edit, AlertCircle 
} from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { daysUntil, formatDate, generateId, getTodayDate, createNotification } from '../../utils/helpers';
import { Step } from '../../types';

const GoalDetail: React.FC = () => {
  const { goalId } = useParams<{ goalId: string }>();
  const navigate = useNavigate();
  const { state, dispatch } = useAppContext();
  
  const goal = state.goals.find(g => g.id === goalId);
  
  const [isAddingStep, setIsAddingStep] = useState(false);
  const [newStep, setNewStep] = useState<Partial<Step>>({
    title: '',
    description: '',
    deadline: '',
    scheduledDate: '',
  });
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  if (!goal) {
    return (
      <div className="text-center py-10">
        <AlertCircle size={48} className="mx-auto text-red-500 mb-4" />
        <h2 className="text-xl font-medium mb-2">Goal Not Found</h2>
        <p className="text-gray-600 mb-4">The goal you're looking for doesn't exist or has been deleted.</p>
        <button 
          onClick={() => navigate('/goals')}
          className="px-4 py-2 bg-blue-600 rounded-md text-white"
        >
          Go to Goals
        </button>
      </div>
    );
  }
  
  const handleAddStepChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNewStep(prev => ({ ...prev, [name]: value }));
  };
  
  const handleAddStep = () => {
    if (!newStep.title || !newStep.deadline || !newStep.scheduledDate) return;
    
    const step: Step = {
      id: generateId(),
      goalId: goal.id,
      title: newStep.title!,
      description: newStep.description || '',
      deadline: newStep.deadline!,
      scheduledDate: newStep.scheduledDate!,
      completed: false,
    };
    
    dispatch({ 
      type: 'ADD_STEP', 
      payload: { 
        goalId: goal.id, 
        step 
      } 
    });
    
    setNewStep({
      title: '',
      description: '',
      deadline: '',
      scheduledDate: '',
    });
    
    setIsAddingStep(false);
  };
  
  const handleCompleteStep = (stepId: string) => {
    dispatch({ 
      type: 'COMPLETE_STEP',
      payload: {
        goalId: goal.id,
        stepId
      }
    });
    
    // Check if all steps are now complete
    const updatedGoal = state.goals.find(g => g.id === goal.id);
    if (updatedGoal && updatedGoal.progress === 100) {
      dispatch({
        type: 'ADD_NOTIFICATION',
        payload: createNotification(
          'Goal Completed! 🎉',
          `Congratulations! You've completed your goal: ${goal.title}`,
          'achievement'
        )
      });
    }
  };
  
  const handleDeleteGoal = () => {
    dispatch({ type: 'DELETE_GOAL', payload: goal.id });
    
    dispatch({
      type: 'ADD_NOTIFICATION',
      payload: createNotification(
        'Goal Deleted',
        `The goal "${goal.title}" has been deleted.`,
        'reminder'
      )
    });
    
    navigate('/goals');
  };
  
  const daysLeft = daysUntil(goal.deadline);
  const sortedSteps = [...goal.steps].sort((a, b) => 
    new Date(a.scheduledDate).getTime() - new Date(b.scheduledDate).getTime()
  );
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center">
          <button
            onClick={() => navigate('/goals')}
            className="mr-4 p-2 rounded-full hover:bg-gray-100"
            aria-label="Go back"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl font-bold">{goal.title}</h1>
        </div>
        
        <div className="flex space-x-2">
          <button
            onClick={() => navigate(`/goals/edit/${goal.id}`)}
            className="px-3 py-1.5 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 flex items-center"
          >
            <Edit size={16} className="mr-1" />
            Edit
          </button>
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="px-3 py-1.5 border border-red-300 rounded-md text-sm font-medium text-red-700 hover:bg-red-50 flex items-center"
          >
            <Trash2 size={16} className="mr-1" />
            Delete
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-white shadow-sm rounded-lg p-6 mb-6">
            <h2 className="text-lg font-medium mb-4">Goal Details</h2>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500">Description</p>
                <p className="text-gray-800">{goal.description || "No description provided."}</p>
              </div>
              
              <div className="flex flex-wrap gap-4">
                <div>
                  <p className="text-sm text-gray-500">Deadline</p>
                  <p className="text-gray-800 flex items-center">
                    <Calendar size={16} className="mr-1" />
                    {formatDate(goal.deadline)}
                  </p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500">Status</p>
                  <p className={`text-sm flex items-center ${
                    goal.completed ? 'text-green-600' : daysLeft < 0 ? 'text-red-600' : 'text-blue-600'
                  }`}>
                    <CheckCircle size={16} className="mr-1" />
                    {goal.completed 
                      ? 'Completed' 
                      : daysLeft < 0 
                        ? 'Overdue' 
                        : daysLeft === 0 
                          ? 'Due today' 
                          : `${daysLeft} days remaining`}
                  </p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500">Progress</p>
                  <div className="flex items-center">
                    <div className="w-32 bg-gray-100 rounded-full h-2.5 mr-2">
                      <div 
                        className="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out"
                        style={{ width: `${goal.progress}%` }}
                      ></div>
                    </div>
                    <span className="text-sm text-gray-600">{goal.progress}%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white shadow-sm rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium">Steps</h2>
              <button
                onClick={() => setIsAddingStep(true)}
                className="px-3 py-1.5 bg-blue-600 rounded-md text-sm font-medium text-white hover:bg-blue-700 flex items-center"
              >
                <Plus size={16} className="mr-1" />
                Add Step
              </button>
            </div>
            
            {isAddingStep && (
              <div className="bg-blue-50 p-4 rounded-lg mb-4">
                <h3 className="font-medium text-sm text-gray-800 mb-3">New Step</h3>
                <div className="space-y-3">
                  <div>
                    <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                      Title*
                    </label>
                    <input
                      type="text"
                      id="title"
                      name="title"
                      value={newStep.title}
                      onChange={handleAddStepChange}
                      className="mt-1 block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                      Description
                    </label>
                    <textarea
                      id="description"
                      name="description"
                      value={newStep.description}
                      onChange={handleAddStepChange}
                      rows={2}
                      className="mt-1 block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label htmlFor="deadline" className="block text-sm font-medium text-gray-700">
                        Deadline*
                      </label>
                      <input
                        type="date"
                        id="deadline"
                        name="deadline"
                        value={newStep.deadline}
                        onChange={handleAddStepChange}
                        min={getTodayDate()}
                        max={goal.deadline}
                        className="mt-1 block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="scheduledDate" className="block text-sm font-medium text-gray-700">
                        Scheduled Date*
                      </label>
                      <input
                        type="date"
                        id="scheduledDate"
                        name="scheduledDate"
                        value={newStep.scheduledDate}
                        onChange={handleAddStepChange}
                        min={getTodayDate()}
                        max={goal.deadline}
                        className="mt-1 block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-end space-x-2 pt-2">
                    <button
                      onClick={() => setIsAddingStep(false)}
                      className="px-3 py-1.5 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleAddStep}
                      className="px-3 py-1.5 bg-blue-600 rounded-md text-sm font-medium text-white hover:bg-blue-700"
                      disabled={!newStep.title || !newStep.deadline || !newStep.scheduledDate}
                    >
                      Save Step
                    </button>
                  </div>
                </div>
              </div>
            )}
            
            {sortedSteps.length === 0 ? (
              <div className="text-center py-10 text-gray-500">
                <p>No steps added yet</p>
                <p className="text-sm mt-1">Add steps to break down your goal</p>
              </div>
            ) : (
              <ul className="divide-y divide-gray-100">
                {sortedSteps.map((step) => (
                  <li key={step.id} className="py-4">
                    <div className="flex items-start">
                      <button
                        onClick={() => handleCompleteStep(step.id)}
                        className={`mt-1 mr-3 flex-shrink-0 h-5 w-5 rounded-full border ${
                          step.completed 
                            ? 'bg-green-500 border-green-500 flex items-center justify-center' 
                            : 'border-gray-300 hover:border-blue-500'
                        }`}
                        aria-label={step.completed ? 'Completed' : 'Mark as completed'}
                      >
                        {step.completed && (
                          <CheckCircle size={14} className="text-white" />
                        )}
                      </button>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className={`font-medium ${step.completed ? 'line-through text-gray-500' : 'text-gray-900'}`}>
                            {step.title}
                          </p>
                          <span className="text-xs text-gray-500">
                            {formatDate(step.scheduledDate)}
                          </span>
                        </div>
                        {step.description && (
                          <p className={`text-sm mt-1 ${step.completed ? 'text-gray-400' : 'text-gray-600'}`}>
                            {step.description}
                          </p>
                        )}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
        
        <div className="lg:col-span-1">
          <div className="bg-white shadow-sm rounded-lg p-6 sticky top-24">
            <h2 className="text-lg font-medium mb-4">Timeline</h2>
            <div className="relative">
              <div className="absolute top-0 bottom-0 left-3 w-0.5 bg-gray-200"></div>
              <ul className="space-y-6">
                {sortedSteps.map((step, index) => (
                  <li key={step.id} className="relative pl-8">
                    <div className={`absolute left-0 top-0 w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                      step.completed 
                        ? 'border-green-500 bg-green-100' 
                        : 'border-blue-500 bg-blue-100'
                    }`}>
                      <span className="text-xs font-medium">{index + 1}</span>
                    </div>
                    <p className={`font-medium ${step.completed ? 'text-gray-500' : 'text-gray-900'}`}>
                      {step.title}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {formatDate(step.scheduledDate)}
                    </p>
                  </li>
                ))}
                <li className="relative pl-8">
                  <div className="absolute left-0 top-0 w-6 h-6 rounded-full border-2 border-purple-500 bg-purple-100 flex items-center justify-center">
                    <span className="text-xs font-medium">✓</span>
                  </div>
                  <p className="font-medium text-gray-900">Goal Completed</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {formatDate(goal.deadline)}
                  </p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-medium text-gray-900 mb-3">Delete Goal</h3>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete "{goal.title}"? This action cannot be undone.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteGoal}
                className="px-4 py-2 bg-red-600 border border-transparent rounded-md text-sm font-medium text-white hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GoalDetail;