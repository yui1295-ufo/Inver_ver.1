import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, CheckCircle, Clock } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { Goal } from '../../types';
import { daysUntil, formatDate } from '../../utils/helpers';

interface GoalItemProps {
  goal: Goal;
}

const GoalItem: React.FC<GoalItemProps> = ({ goal }) => {
  const navigate = useNavigate();
  const { dispatch } = useAppContext();
  
  const daysRemaining = daysUntil(goal.deadline);
  
  const getStatusColor = () => {
    if (goal.completed) return 'bg-green-100 text-green-800';
    if (daysRemaining < 0) return 'bg-red-100 text-red-800';
    if (daysRemaining < 3) return 'bg-amber-100 text-amber-800';
    return 'bg-blue-100 text-blue-800';
  };
  
  const getStatusText = () => {
    if (goal.completed) return 'Completed';
    if (daysRemaining < 0) return 'Overdue';
    if (daysRemaining === 0) return 'Due today';
    return `${daysRemaining} days left`;
  };
  
  const handleViewDetails = () => {
    dispatch({ type: 'SET_ACTIVE_GOAL', payload: goal.id });
    navigate(`/goals/${goal.id}`);
  };
  
  return (
    <div className="bg-white rounded-lg shadow-sm p-5 hover:shadow-md transition-shadow duration-300">
      <div className="flex justify-between items-start mb-3">
        <h3 className="font-medium text-gray-900 truncate flex-1">{goal.title}</h3>
        <span 
          className={`text-xs px-2 py-1 rounded-full ${getStatusColor()} ml-2 flex-shrink-0 flex items-center`}
        >
          {goal.completed ? (
            <CheckCircle size={12} className="mr-1" />
          ) : (
            <Clock size={12} className="mr-1" />
          )}
          {getStatusText()}
        </span>
      </div>
      
      <p className="text-sm text-gray-600 mb-4 line-clamp-2">
        {goal.description}
      </p>
      
      <div className="mb-3">
        <div className="flex justify-between text-xs text-gray-500 mb-1">
          <span>{goal.progress}% complete</span>
          <span>Due {formatDate(goal.deadline)}</span>
        </div>
        <div className="w-full bg-gray-100 rounded-full h-2.5">
          <div 
            className="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${goal.progress}%` }}
          ></div>
        </div>
      </div>
      
      <div className="flex justify-between items-center">
        <span className="text-xs text-gray-500">
          {goal.steps.length > 0 
            ? `${goal.steps.filter(s => s.completed).length}/${goal.steps.length} steps completed` 
            : 'No steps defined'}
        </span>
        <button
          onClick={handleViewDetails}
          className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center"
        >
          View Details
          <ArrowRight size={16} className="ml-1" />
        </button>
      </div>
    </div>
  );
};

export default GoalItem;