import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../../context/AppContext';
import { generateId, getTodayDate, createNotification } from '../../utils/helpers';
import { Goal } from '../../types';

interface GoalFormProps {
  onCancel?: () => void;
}

const GoalForm: React.FC<GoalFormProps> = ({ onCancel }) => {
  const navigate = useNavigate();
  const { dispatch } = useAppContext();
  const [useAI, setUseAI] = useState(false);
  
  const [goalData, setGoalData] = useState({
    title: '',
    description: '',
    deadline: '',
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!goalData.title.trim()) {
      newErrors.title = 'Title is required';
    }
    
    if (!goalData.deadline) {
      newErrors.deadline = 'Deadline is required';
    } else if (new Date(goalData.deadline) < new Date()) {
      newErrors.deadline = 'Deadline cannot be in the past';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setGoalData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate()) return;
    
    if (useAI) {
      // Navigate to AI assistant
      navigate('/goals/ai-assistant', { state: { goalData } });
      return;
    }
    
    // Create new goal
    const newGoal: Goal = {
      id: generateId(),
      ...goalData,
      createdAt: new Date().toISOString(),
      steps: [],
      aiGenerated: false,
      completed: false,
      progress: 0
    };
    
    dispatch({ type: 'ADD_GOAL', payload: newGoal });
    
    // Create notification
    dispatch({
      type: 'ADD_NOTIFICATION',
      payload: createNotification(
        'New Goal Created',
        `You've created a new goal: ${newGoal.title}`,
        'reminder'
      )
    });
    
    navigate('/goals');
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <h2 className="text-xl font-medium text-gray-900 mb-4">Create New Goal</h2>
        
        <div className="mb-6">
          <label className="block text-gray-700 mb-2 text-sm font-medium" htmlFor="goal-method">
            How would you like to create your goal?
          </label>
          <div className="flex space-x-4">
            <label className="flex items-center">
              <input
                type="radio"
                className="mr-2 h-4 w-4 text-blue-600"
                checked={!useAI}
                onChange={() => setUseAI(false)}
              />
              <span>Create manually</span>
            </label>
            <label className="flex items-center">
              <input
                type="radio"
                className="mr-2 h-4 w-4 text-blue-600"
                checked={useAI}
                onChange={() => setUseAI(true)}
              />
              <span>Use AI assistant</span>
            </label>
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-gray-700">
              Goal Title*
            </label>
            <input
              type="text"
              id="title"
              name="title"
              value={goalData.title}
              onChange={handleChange}
              className={`mt-1 block w-full rounded-md shadow-sm py-2 px-3 border ${
                errors.title ? 'border-red-300' : 'border-gray-300'
              } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
              placeholder="E.g., Learn Spanish"
            />
            {errors.title && (
              <p className="mt-1 text-sm text-red-600">{errors.title}</p>
            )}
          </div>
          
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700">
              Description
            </label>
            <textarea
              id="description"
              name="description"
              value={goalData.description}
              onChange={handleChange}
              rows={3}
              className="mt-1 block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Why is this goal important to you?"
            />
          </div>
          
          <div>
            <label htmlFor="deadline" className="block text-sm font-medium text-gray-700">
              Deadline*
            </label>
            <input
              type="date"
              id="deadline"
              name="deadline"
              value={goalData.deadline}
              onChange={handleChange}
              min={getTodayDate()}
              className={`mt-1 block w-full rounded-md shadow-sm py-2 px-3 border ${
                errors.deadline ? 'border-red-300' : 'border-gray-300'
              } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
            />
            {errors.deadline && (
              <p className="mt-1 text-sm text-red-600">{errors.deadline}</p>
            )}
          </div>
        </div>
      </div>
      
      <div className="flex justify-end space-x-4">
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
          >
            Cancel
          </button>
        )}
        <button
          type="submit"
          className="px-4 py-2 bg-blue-600 border border-transparent rounded-md text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          {useAI ? 'Continue with AI Assistant' : 'Create Goal'}
        </button>
      </div>
    </form>
  );
};

export default GoalForm;