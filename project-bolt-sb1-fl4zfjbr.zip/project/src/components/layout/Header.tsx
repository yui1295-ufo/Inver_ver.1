import React, { useState } from 'react';
import { Bell, Menu, X } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import NotificationPanel from '../notifications/NotificationPanel';

interface HeaderProps {
  toggleSidebar: () => void;
  isSidebarOpen: boolean;
}

const Header: React.FC<HeaderProps> = ({ toggleSidebar, isSidebarOpen }) => {
  const { state } = useAppContext();
  const [showNotifications, setShowNotifications] = useState(false);
  
  const unreadCount = state.notifications.filter(n => !n.read).length;

  return (
    <header className="bg-white shadow-sm h-16 fixed top-0 left-0 right-0 z-10">
      <div className="h-full flex items-center justify-between px-4">
        <div className="flex items-center">
          <button 
            onClick={toggleSidebar}
            className="p-2 mr-4 rounded-md hover:bg-gray-100 transition-colors duration-200 lg:hidden"
            aria-label={isSidebarOpen ? "Close sidebar" : "Open sidebar"}
          >
            {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
          
          <h1 className="text-xl font-bold text-gray-800">Objective Calendar</h1>
        </div>
        
        <div className="relative">
          <button 
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 rounded-full hover:bg-gray-100 transition-colors duration-200 relative"
            aria-label="Notifications"
          >
            <Bell size={24} />
            {unreadCount > 0 && (
              <span className="absolute top-0 right-0 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>
          
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96">
              <NotificationPanel onClose={() => setShowNotifications(false)} />
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;