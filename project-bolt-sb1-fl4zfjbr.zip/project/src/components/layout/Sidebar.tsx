import React from 'react';
import { Calendar, BarChart2, Target, Settings } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

interface SidebarProps {
  isOpen: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen }) => {
  const location = useLocation();
  
  const navItems = [
    { 
      path: '/', 
      label: 'Dashboard', 
      icon: <BarChart2 size={20} />,
      exact: true
    },
    { 
      path: '/goals', 
      label: 'Goals', 
      icon: <Target size={20} /> 
    },
    { 
      path: '/calendar', 
      label: 'Calendar', 
      icon: <Calendar size={20} /> 
    },
    { 
      path: '/settings', 
      label: 'Settings', 
      icon: <Settings size={20} /> 
    }
  ];

  const isActive = (path: string, exact = false): boolean => {
    if (exact) return location.pathname === path;
    return location.pathname.startsWith(path);
  };

  return (
    <aside 
      className={`fixed top-16 left-0 h-[calc(100vh-4rem)] bg-white shadow-sm z-10 transition-all duration-300 transform 
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        lg:translate-x-0 w-64`}
    >
      <nav className="p-4">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.path}>
              <Link
                to={item.path}
                className={`flex items-center rounded-lg p-3 transition-colors hover:bg-gray-100
                  ${isActive(item.path, item.exact) 
                    ? 'bg-blue-50 text-blue-600 font-medium' 
                    : 'text-gray-700'}`}
              >
                <span className="mr-3">{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;