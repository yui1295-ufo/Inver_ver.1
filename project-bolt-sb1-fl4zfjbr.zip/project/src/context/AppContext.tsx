import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { AppState, Goal, Notification, Step } from '../types';

type AppAction = 
  | { type: 'ADD_GOAL'; payload: Goal }
  | { type: 'UPDATE_GOAL'; payload: Goal }
  | { type: 'DELETE_GOAL'; payload: string }
  | { type: 'COMPLETE_GOAL'; payload: string }
  | { type: 'ADD_STEP'; payload: { goalId: string; step: Step } }
  | { type: 'UPDATE_STEP'; payload: Step }
  | { type: 'COMPLETE_STEP'; payload: { goalId: string; stepId: string } }
  | { type: 'ADD_NOTIFICATION'; payload: Notification }
  | { type: 'READ_NOTIFICATION'; payload: string }
  | { type: 'SET_ACTIVE_GOAL'; payload: string | null };

const initialState: AppState = {
  goals: [],
  notifications: [],
  activeGoal: null,
};

// Load state from localStorage if available
const loadInitialState = (): AppState => {
  const savedState = localStorage.getItem('appState');
  return savedState ? JSON.parse(savedState) : initialState;
};

const appReducer = (state: AppState, action: AppAction): AppState => {
  switch (action.type) {
    case 'ADD_GOAL':
      return {
        ...state,
        goals: [...state.goals, action.payload],
      };
    case 'UPDATE_GOAL':
      return {
        ...state,
        goals: state.goals.map(goal => 
          goal.id === action.payload.id ? action.payload : goal
        ),
      };
    case 'DELETE_GOAL':
      return {
        ...state,
        goals: state.goals.filter(goal => goal.id !== action.payload),
      };
    case 'COMPLETE_GOAL':
      return {
        ...state,
        goals: state.goals.map(goal => 
          goal.id === action.payload 
            ? { ...goal, completed: true, progress: 100 } 
            : goal
        ),
      };
    case 'ADD_STEP':
      return {
        ...state,
        goals: state.goals.map(goal => 
          goal.id === action.payload.goalId 
            ? { ...goal, steps: [...goal.steps, action.payload.step] } 
            : goal
        ),
      };
    case 'UPDATE_STEP':
      return {
        ...state,
        goals: state.goals.map(goal => 
          goal.id === action.payload.goalId 
            ? { 
                ...goal, 
                steps: goal.steps.map(step => 
                  step.id === action.payload.id ? action.payload : step
                ) 
              } 
            : goal
        ),
      };
    case 'COMPLETE_STEP': {
      // Find the goal and update the step
      const updatedGoals = state.goals.map(goal => {
        if (goal.id !== action.payload.goalId) return goal;
        
        // Update the step
        const updatedSteps = goal.steps.map(step => 
          step.id === action.payload.stepId 
            ? { ...step, completed: true } 
            : step
        );
        
        // Calculate new progress
        const completedSteps = updatedSteps.filter(step => step.completed).length;
        const progress = updatedSteps.length > 0 
          ? Math.round((completedSteps / updatedSteps.length) * 100)
          : 0;
        
        return {
          ...goal,
          steps: updatedSteps,
          progress,
          completed: progress === 100
        };
      });
      
      return {
        ...state,
        goals: updatedGoals,
      };
    }
    case 'ADD_NOTIFICATION':
      return {
        ...state,
        notifications: [action.payload, ...state.notifications],
      };
    case 'READ_NOTIFICATION':
      return {
        ...state,
        notifications: state.notifications.map(notification => 
          notification.id === action.payload 
            ? { ...notification, read: true } 
            : notification
        ),
      };
    case 'SET_ACTIVE_GOAL':
      return {
        ...state,
        activeGoal: action.payload,
      };
    default:
      return state;
  }
};

interface AppContextProps {
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
}

const AppContext = createContext<AppContextProps | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState, loadInitialState);

  // Save state to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('appState', JSON.stringify(state));
  }, [state]);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};