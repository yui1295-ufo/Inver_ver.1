import React from 'react';
import AIAssistant from '../components/goals/AIAssistant';

const AIAssistantPage: React.FC = () => {
  return (
    <div>
      <AIAssistant />
    </div>
  );
};

export default AIAssistantPage;