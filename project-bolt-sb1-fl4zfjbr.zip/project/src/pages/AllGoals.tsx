import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Filter, Search } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import GoalItem from '../components/goals/GoalItem';

const AllGoals: React.FC = () => {
  const navigate = useNavigate();
  const { state } = useAppContext();
  const [filterCompleted, setFilterCompleted] = useState<boolean | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  const handleAddGoal = () => {
    navigate('/goals/new');
  };
  
  // Filter goals based on selected filters and search query
  const filteredGoals = state.goals.filter(goal => {
    // Apply completed filter if selected
    if (filterCompleted !== null && goal.completed !== filterCompleted) {
      return false;
    }
    
    // Apply search filter if query exists
    if (searchQuery.trim() && !goal.title.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    return true;
  });
  
  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-6 flex flex-wrap justify-between items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Your Goals</h1>
          <p className="text-gray-600">Manage and track your objectives</p>
        </div>
        <button
          onClick={handleAddGoal}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
        >
          <Plus size={18} className="mr-2" />
          New Goal
        </button>
      </div>
      
      <div className="bg-white p-4 rounded-lg shadow-sm mb-6 flex flex-wrap gap-4">
        <div className="flex-1 min-w-[200px]">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search goals..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full py-2 pl-10 pr-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Filter size={18} className="text-gray-500" />
          <span className="text-sm text-gray-700">Filter:</span>
          <select
            value={filterCompleted === null ? 'all' : filterCompleted ? 'completed' : 'active'}
            onChange={(e) => {
              const value = e.target.value;
              setFilterCompleted(
                value === 'all' ? null : value === 'completed'
              );
            }}
            className="py-2 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Goals</option>
            <option value="active">In Progress</option>
            <option value="completed">Completed</option>
          </select>
        </div>
      </div>
      
      {filteredGoals.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow-sm">
          <h2 className="text-xl font-medium text-gray-900 mb-2">No goals found</h2>
          <p className="text-gray-600 mb-6">
            {searchQuery || filterCompleted !== null
              ? "No goals match your current filters. Try adjusting your search or filters."
              : "You haven't created any goals yet. Click the button below to get started!"}
          </p>
          <button
            onClick={handleAddGoal}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 inline-flex items-center"
          >
            <Plus size={18} className="mr-2" />
            Create Your First Goal
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGoals.map(goal => (
            <GoalItem key={goal.id} goal={goal} />
          ))}
        </div>
      )}
    </div>
  );
};

export default AllGoals;