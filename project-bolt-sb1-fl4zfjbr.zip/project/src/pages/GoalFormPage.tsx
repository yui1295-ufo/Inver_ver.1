import React from 'react';
import { useNavigate } from 'react-router-dom';
import GoalForm from '../components/goals/GoalForm';

const GoalFormPage: React.FC = () => {
  const navigate = useNavigate();
  
  const handleCancel = () => {
    navigate('/goals');
  };
  
  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Create New Goal</h1>
        <p className="text-gray-600">Define your objectives and create a plan</p>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm p-6">
        <GoalForm onCancel={handleCancel} />
      </div>
    </div>
  );
};

export default GoalFormPage;