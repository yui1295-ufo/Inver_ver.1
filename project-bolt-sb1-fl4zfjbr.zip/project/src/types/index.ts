export interface Goal {
  id: string;
  title: string;
  description: string;
  deadline: string;
  createdAt: string;
  steps: Step[];
  aiGenerated: boolean;
  completed: boolean;
  progress: number;
}

export interface Step {
  id: string;
  goalId: string;
  title: string;
  description: string;
  deadline: string;
  completed: boolean;
  scheduledDate: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
  type: 'deadline' | 'reminder' | 'achievement';
}

export interface AppState {
  goals: Goal[];
  notifications: Notification[];
  activeGoal: string | null;
}

export interface ChartData {
  label: string;
  value: number;
}