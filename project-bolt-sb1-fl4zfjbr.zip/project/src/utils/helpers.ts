import { Goal, Step, Notification } from '../types';

// Generate a unique ID
export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
};

// Get today's date in YYYY-MM-DD format
export const getTodayDate = (): string => {
  return new Date().toISOString().split('T')[0];
};

// Format date to display (e.g., "Mon, Jan 1, 2025")
export const formatDate = (dateString: string): string => {
  const options: Intl.DateTimeFormatOptions = { 
    weekday: 'short', 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  };
  return new Date(dateString).toLocaleDateString(undefined, options);
};

// Calculate days remaining until a deadline
export const daysUntil = (deadline: string): number => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const deadlineDate = new Date(deadline);
  const diffTime = deadlineDate.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

// Get tasks scheduled for today
export const getTodayTasks = (goals: Goal[]): Step[] => {
  const today = getTodayDate();
  return goals.flatMap(goal => 
    goal.steps.filter(step => 
      step.scheduledDate === today && !step.completed
    )
  );
};

// Sort goals by deadline (closest first)
export const sortGoalsByDeadline = (goals: Goal[]): Goal[] => {
  return [...goals].sort((a, b) => 
    new Date(a.deadline).getTime() - new Date(b.deadline).getTime()
  );
};

// Create a new notification
export const createNotification = (
  title: string, 
  message: string, 
  type: Notification['type'] = 'reminder'
): Notification => {
  return {
    id: generateId(),
    title,
    message,
    read: false,
    createdAt: new Date().toISOString(),
    type
  };
};

// Calculate weekly goal achievement rate
export const calculateWeeklyAchievementRate = (goals: Goal[]): number => {
  const now = new Date();
  const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
  weekStart.setHours(0, 0, 0, 0);
  
  const weekGoals = goals.filter(goal => {
    const createdDate = new Date(goal.createdAt);
    return createdDate >= weekStart;
  });
  
  if (weekGoals.length === 0) return 0;
  
  const completedGoals = weekGoals.filter(goal => goal.completed).length;
  return Math.round((completedGoals / weekGoals.length) * 100);
};

// Get month names for charts
export const getMonthNames = (): string[] => {
  return [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
};