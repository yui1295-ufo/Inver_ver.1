import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import Layout from './components/layout/Layout';
import Dashboard from './components/dashboard/Dashboard';
import AllGoals from './pages/AllGoals';
import GoalDetail from './components/goals/GoalDetail';
import GoalFormPage from './pages/GoalFormPage';
import AIAssistantPage from './pages/AIAssistantPage';
import CalendarView from './components/calendar/CalendarView';
import DayView from './components/calendar/DayView';
import Settings from './components/settings/Settings';

function App() {
  return (
    <AppProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="goals" element={<AllGoals />} />
            <Route path="goals/new" element={<GoalFormPage />} />
            <Route path="goals/:goalId" element={<GoalDetail />} />
            <Route path="goals/ai-assistant" element={<AIAssistantPage />} />
            <Route path="calendar" element={<CalendarView />} />
            <Route path="calendar/day/:date" element={<DayView />} />
            <Route path="settings" element={<Settings />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </Router>
    </AppProvider>
  );
}

export default App;